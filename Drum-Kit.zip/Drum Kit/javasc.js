
// function to make a sound 
function play(key){

    let audio = document.querySelector(`audio[data-key="${key}"]`);
    if(audio) audio.play();   
  }

// js know button click or not
  document.onclick = e=>{

    if(e.target.dataset.key) play(e.target.dataset.key)
  }

// js know which key user-click
window.onkeydown = e=>{

  play(e.keyCode)
}